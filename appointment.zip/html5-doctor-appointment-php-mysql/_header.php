        <div class="header">
            <h1>Efficient Doctor Patient Portal</h1>
              <div class="img1" align="left"><image src="logo.jpg"></div>
            <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<!-- The form -->
<form class="example" action="action_page.php">
  <input type="text" placeholder="Search.." name="search">
  <button type="submit"><i class="fa fa-search"></i></button>
</form>
            </div>
