            <div class="space">
                <a href="index.php">Public</a>
                |
                <a href="doctor.php">Doctor</a>
                |
                <a href="manager.php">Manager</a>
            </div>
